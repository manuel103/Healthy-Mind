Call-Recorder
=========================
Introduction
-----------------
This android application allows you to record all incoming and outgoing calls from your phone.All your recorded calls are saved in 3gp files and can be sent from the application.You can enable/disable the recording during the call, or leave it enabled to record all the calls.The main application screen contains a list of all calls with details of phone numbers, date and time of a call. By selecting one of the items the application will provide you with 3 options:send record and play record.You can also change the background color for the application in the part " Change Theme ".If you like .Please Donate.

![alt text](https://github.com/HarryHaiVn/Call-Recorder/blob/master/home.gif)
![alt text](https://github.com/HarryHaiVn/Call-Recorder/blob/master/menu.gif)

Link App
-----------------
(https://play.google.com/store/apps/details?id=vn.harry.callrecorder)

Discussions
-----------------
Refer to the issues section: https://github.com/HarryHaiVn/Call-Recorder/issues