package vn.harry.callrecorder.mvp;

public interface BaseMvpView {
    void onResponseError(int apiMethod, int statusCode);
}
