package vn.harry.callrecorder.recycle.viewholder;

import android.support.v7.widget.RecyclerView;
import android.view.View;

import vn.harry.callrecorder.R;

public class SimpleViewHolder extends RecyclerView.ViewHolder {

    public static final int LAYOUT_ID = R.layout.layout_empty_view;

    public SimpleViewHolder(View itemView) {
        super(itemView);
    }
}
