package vn.harry.callrecorder.ui.setting;

import vn.harry.callrecorder.mvp.BasePresenter;

/**
 * Created by Harry_Hai on 2/13/2018.
 */

public class SettingPresenter extends BasePresenter<SettingMvpView> {
}
