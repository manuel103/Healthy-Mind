package vn.harry.callrecorder.recycle.viewholder;

import android.support.v7.widget.RecyclerView;
import android.view.View;

import vn.harry.callrecorder.R;

public class DefaultLoadMoreViewHolder extends RecyclerView.ViewHolder {

    public static final int LAYOUT_ID = R.layout.load_more;

    public DefaultLoadMoreViewHolder(View itemView) {
        super(itemView);
    }

}
