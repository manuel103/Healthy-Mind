package vn.harry.callrecorder.ui.setting;

import vn.harry.callrecorder.mvp.BaseMvpView;

/**
 * Created by Harry_Hai on 2/13/2018.
 */

public interface SettingMvpView extends BaseMvpView {
}
