package vn.harry.callrecorder.util;

/**
 * Created by Harry_Hai on 2/18/2018.
 */

public interface OnChangeSwitchListener {
    void onChangeSwitch();
}
