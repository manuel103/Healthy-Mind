package vn.harry.callrecorder.response;

public class BaseResponse {
}
