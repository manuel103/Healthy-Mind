package vn.harry.callrecorder.ui.donate;

import vn.harry.callrecorder.mvp.BasePresenter;

/**
 * Created by hainm on 2/21/2018.
 */

public class DonateOptionPresenter extends BasePresenter<DonateOptionMvp> {
}
