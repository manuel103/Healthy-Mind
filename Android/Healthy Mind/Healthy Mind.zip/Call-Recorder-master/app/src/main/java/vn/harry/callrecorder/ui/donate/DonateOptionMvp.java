package vn.harry.callrecorder.ui.donate;

import vn.harry.callrecorder.mvp.BaseMvpView;

/**
 * Created by hainm on 2/21/2018.
 */

public interface DonateOptionMvp extends BaseMvpView {
}
