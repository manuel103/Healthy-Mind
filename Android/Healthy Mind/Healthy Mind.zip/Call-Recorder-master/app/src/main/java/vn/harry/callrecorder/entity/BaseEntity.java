package vn.harry.callrecorder.entity;

public class BaseEntity {
}
