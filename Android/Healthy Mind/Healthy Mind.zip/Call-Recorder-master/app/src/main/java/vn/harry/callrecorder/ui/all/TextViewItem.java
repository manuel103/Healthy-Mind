package vn.harry.callrecorder.ui.all;

/**
 * Created by Harry_Hai on 2/18/2018.
 */

public class TextViewItem {
    public String header;

    public TextViewItem(String header) {
        this.header = header;
    }

    public String getHeader() {
        return header;
    }
}
